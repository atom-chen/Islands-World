---@class Coolape.CLUIPlaySound : UIPlaySound
---@field public soundFileName System.String
---@field public soundName System.String

local m = { }
---public CLUIPlaySound .ctor()
---@return CLUIPlaySound
function m.New() end
---public Void Play()
function m:Play() end
Coolape.CLUIPlaySound = m
return m
