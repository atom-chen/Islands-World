---@class UISlider : UIProgressBar

local m = { }
---public UISlider .ctor()
---@return UISlider
function m.New() end
UISlider = m
return m
