---@class Coolape.CLButtonMsgLua : UIEventListener
---@field public target Coolape.CLPanelLua
---@field public target2 Coolape.CLCellLua
---@field public trigger Coolape.CLButtonMsgLua.Trigger
---@field public functionName System.String

local m = { }
---public CLButtonMsgLua .ctor()
---@return CLButtonMsgLua
function m.New() end
Coolape.CLButtonMsgLua = m
return m
