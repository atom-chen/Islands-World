---@class Coolape.CLVerManager : Coolape.CLBaseLua
---@field public baseUrl System.String
---@field public platform System.String
---@field public self Coolape.CLVerManager
---@field public resVer System.String
---@field public versPath System.String
---@field public fverVer System.String
---@field public verPriority System.String
---@field public localPriorityVer System.Collections.Hashtable
---@field public verOthers System.String
---@field public otherResVerOld System.Collections.Hashtable
---@field public otherResVerNew System.Collections.Hashtable
---@field public haveUpgrade System.Boolean
---@field public is2GNetUpgrade System.Boolean
---@field public is3GNetUpgrade System.Boolean
---@field public is4GNetUpgrade System.Boolean
---@field public mVerverPath System.String
---@field public mVerPrioriPath System.String
---@field public mVerOtherPath System.String
---@field public wwwMap System.Collections.Hashtable
---@field public clientVersion System.String

local m = { }
---public CLVerManager .ctor()
---@return CLVerManager
function m.New() end
---public Void initStreamingAssetsPackge(Callback onFinisInitStreaming)
---@param optional Callback onFinisInitStreaming
function m:initStreamingAssetsPackge(onFinisInitStreaming) end
---public Hashtable toMap(Byte[] buffer)
---@return Hashtable
---@param optional Byte[] buffer
function m:toMap(buffer) end
---public Void getNewestRes4Lua(String path, CLAssetType t, Object onGetAsset, Object originals)
---@param optional String path
---@param optional CLAssetType t
---@param optional Object onGetAsset
---@param optional Object originals
function m:getNewestRes4Lua(path, type, onGetAsset, originals) end
---public Void getNewestRes(String path, CLAssetType t, Object onGetAsset, Object[] originals)
---@param optional String path
---@param optional CLAssetType t
---@param optional Object onGetAsset
---@param optional Object[] originals
function m:getNewestRes(path, type, onGetAsset, originals) end
---public Void setWWWListner(Object addWWWcb, Object rmWWWcb)
---@param optional Object addWWWcb
---@param optional Object rmWWWcb
function m:setWWWListner(addWWWcb, rmWWWcb) end
---public Void addWWW(WWW www, String path, String url)
---@param optional WWW www
---@param optional String path
---@param optional String url
function m:addWWW(www, path, url) end
---public Void rmWWW(String url)
---@param optional String url
function m:rmWWW(url) end
---public IEnumerator doGetContent(String path, String url, Boolean needSave, CLAssetType t, Object onGetAsset, Object[] originals)
---@return IEnumerator
---@param optional String path
---@param optional String url
---@param optional Boolean needSave
---@param optional CLAssetType t
---@param optional Object onGetAsset
---@param optional Object[] originals
function m:doGetContent(path, url, needSave, type, onGetAsset, originals) end
---public Void onGetNewstResTimeOut(Object[] args)
---@param optional Object[] args
function m:onGetNewstResTimeOut(args) end
---public Texture getAtalsTexture4Edit(String path)
---@return Texture
---@param optional String path
function m:getAtalsTexture4Edit(path) end
---public Boolean checkNeedDownload(String path)
---@return bool
---@param optional String path
function m:checkNeedDownload(path) end
---public Boolean isVerNewest(String path, String ver)
---@return bool
---@param optional String path
---@param optional String ver
function m:isVerNewest(path, ver) end
Coolape.CLVerManager = m
return m
