---@class UnityEngine.Keyframe : System.ValueType
---@field public time System.Single
---@field public value System.Single
---@field public inTangent System.Single
---@field public outTangent System.Single
---@field public tangentMode System.Int32

local m = { }
---public Keyframe .ctor(Single time, Single value)
---public Keyframe .ctor(Single time, Single value, Single inTangent, Single outTangent)
---@return Keyframe
---@param Single time
---@param Single value
---@param optional Single inTangent
---@param optional Single outTangent
function m.New(time, value, inTangent, outTangent) end
UnityEngine.Keyframe = m
return m
