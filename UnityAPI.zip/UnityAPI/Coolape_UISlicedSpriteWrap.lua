---@class Coolape.UISlicedSprite : UISprite
---@field public mCenter UIWidget

local m = { }
---public UISlicedSprite .ctor()
---@return UISlicedSprite
function m.New() end
---public Void refreshCenter()
function m:refreshCenter() end
Coolape.UISlicedSprite = m
return m
