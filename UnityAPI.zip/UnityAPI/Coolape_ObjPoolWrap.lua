---@class Coolape.ObjPool
---@field public strs Coolape.StringPool
---@field public maps Coolape.MapPool
---@field public sets Coolape.SetPool
---@field public listPool Coolape.ListPool

