---@class Coolape.CLCellBase : Coolape.CLBehaviour4Lua

local m = { }
---public Void init(Object data, Object onClick)
---@param optional Object data
---@param optional Object onClick
function m:init(data, onClick) end
Coolape.CLCellBase = m
return m
