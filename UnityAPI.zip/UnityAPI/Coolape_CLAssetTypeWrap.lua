---@class Coolape.CLAssetType : System.Enum
---@field public value__ System.Int32
---@field public text Coolape.CLAssetType
---@field public bytes Coolape.CLAssetType
---@field public texture Coolape.CLAssetType
---@field public assetBundle Coolape.CLAssetType

