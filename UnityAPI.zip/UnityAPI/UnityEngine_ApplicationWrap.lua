---@class UnityEngine.Application
---@field public streamedBytes System.Int32
---@field public isPlaying System.Boolean
---@field public isFocused System.Boolean
---@field public isEditor System.Boolean
---@field public platform UnityEngine.RuntimePlatform
---@field public buildGUID System.String
---@field public isMobilePlatform System.Boolean
---@field public isConsolePlatform System.Boolean
---@field public runInBackground System.Boolean
---@field public dataPath System.String
---@field public streamingAssetsPath System.String
---@field public persistentDataPath System.String
---@field public temporaryCachePath System.String
---@field public absoluteURL System.String
---@field public unityVersion System.String
---@field public version System.String
---@field public installerName System.String
---@field public identifier System.String
---@field public installMode UnityEngine.ApplicationInstallMode
---@field public sandboxType UnityEngine.ApplicationSandboxType
---@field public productName System.String
---@field public companyName System.String
---@field public cloudProjectId System.String
---@field public targetFrameRate System.Int32
---@field public systemLanguage UnityEngine.SystemLanguage
---@field public backgroundLoadingPriority UnityEngine.ThreadPriority
---@field public internetReachability UnityEngine.NetworkReachability
---@field public genuine System.Boolean
---@field public genuineCheckAvailable System.Boolean

local m = { }
---public Application .ctor()
---@return Application
function m.New() end
---public Void add_lowMemory(LowMemoryCallback value)
---@param optional LowMemoryCallback value
function m.add_lowMemory(value) end
---public Void remove_lowMemory(LowMemoryCallback value)
---@param optional LowMemoryCallback value
function m.remove_lowMemory(value) end
---public Void Quit()
function m.Quit() end
---public Void CancelQuit()
function m.CancelQuit() end
---public Void Unload()
function m.Unload() end
---public Single GetStreamProgressForLevel(String levelName)
---public Single GetStreamProgressForLevel(Int32 levelIndex)
---@return number
---@param optional Int32 levelIndex
function m.GetStreamProgressForLevel(levelIndex) end
---public Boolean CanStreamedLevelBeLoaded(String levelName)
---public Boolean CanStreamedLevelBeLoaded(Int32 levelIndex)
---@return bool
---@param optional Int32 levelIndex
function m.CanStreamedLevelBeLoaded(levelIndex) end
---public String[] GetBuildTags()
---@return table
function m.GetBuildTags() end
---public Void SetBuildTags(String[] buildTags)
---@param optional String[] buildTags
function m.SetBuildTags(buildTags) end
---public Boolean HasProLicense()
---@return bool
function m.HasProLicense() end
---public Boolean RequestAdvertisingIdentifierAsync(AdvertisingIdentifierCallback delegateMethod)
---@return bool
---@param optional AdvertisingIdentifierCallback delegateMethod
function m.RequestAdvertisingIdentifierAsync(delegateMethod) end
---public Void OpenURL(String url)
---@param optional String url
function m.OpenURL(url) end
---public Void add_logMessageReceived(LogCallback value)
---@param optional LogCallback value
function m.add_logMessageReceived(value) end
---public Void remove_logMessageReceived(LogCallback value)
---@param optional LogCallback value
function m.remove_logMessageReceived(value) end
---public Void add_logMessageReceivedThreaded(LogCallback value)
---@param optional LogCallback value
function m.add_logMessageReceivedThreaded(value) end
---public Void remove_logMessageReceivedThreaded(LogCallback value)
---@param optional LogCallback value
function m.remove_logMessageReceivedThreaded(value) end
---public StackTraceLogType GetStackTraceLogType(LogType logType)
---@return number
---@param optional LogType logType
function m.GetStackTraceLogType(logType) end
---public Void SetStackTraceLogType(LogType logType, StackTraceLogType stackTraceType)
---@param optional LogType logType
---@param optional StackTraceLogType stackTraceType
function m.SetStackTraceLogType(logType, stackTraceType) end
---public AsyncOperation RequestUserAuthorization(UserAuthorization mode)
---@return AsyncOperation
---@param optional UserAuthorization mode
function m.RequestUserAuthorization(mode) end
---public Boolean HasUserAuthorization(UserAuthorization mode)
---@return bool
---@param optional UserAuthorization mode
function m.HasUserAuthorization(mode) end
---public Void add_onBeforeRender(UnityAction value)
---@param optional UnityAction value
function m.add_onBeforeRender(value) end
---public Void remove_onBeforeRender(UnityAction value)
---@param optional UnityAction value
function m.remove_onBeforeRender(value) end
UnityEngine.Application = m
return m
