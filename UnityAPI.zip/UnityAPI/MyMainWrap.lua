---@class MyMain : Coolape.CLMainBase

local m = { }
---public MyMain .ctor()
---@return MyMain
function m.New() end
---public Void init()
function m:init() end
---public Void doOffline()
function m:doOffline() end
MyMain = m
return m
