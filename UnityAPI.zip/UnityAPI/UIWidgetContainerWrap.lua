---@class UIWidgetContainer : UnityEngine.MonoBehaviour

local m = { }
---public UIWidgetContainer .ctor()
---@return UIWidgetContainer
function m.New() end
UIWidgetContainer = m
return m
