---@class UILocalize : UnityEngine.MonoBehaviour
---@field public key System.String
---@field public value System.String

local m = { }
---public UILocalize .ctor()
---@return UILocalize
function m.New() end
UILocalize = m
return m
