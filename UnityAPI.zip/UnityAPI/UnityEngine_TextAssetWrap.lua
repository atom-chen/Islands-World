---@class UnityEngine.TextAsset : UnityEngine.Object
---@field public text System.String
---@field public bytes System.Byte

local m = { }
---public TextAsset .ctor()
---@return TextAsset
function m.New() end
---public String ToString()
---@return String
function m:ToString() end
UnityEngine.TextAsset = m
return m
