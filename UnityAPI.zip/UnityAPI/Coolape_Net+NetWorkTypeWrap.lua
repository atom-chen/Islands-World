---@class Coolape.Net+NetWorkType : System.Enum
---@field public value__ System.Int32
---@field public publish Coolape.Net.NetWorkType
---@field public test1 Coolape.Net.NetWorkType
---@field public test2 Coolape.Net.NetWorkType

