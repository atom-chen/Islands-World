---@class Coolape.B2Int
---@field public value System.Int32

local m = { }
---public B2Int .ctor(Int32 v)
---@return B2Int
---@param optional Int32 v
function m.New(v) end
Coolape.B2Int = m
return m
